﻿
using var game = new GradedUnit.Game1();
game.Run();
